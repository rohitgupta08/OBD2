import { Component, NgZone } from "@angular/core";
import { NavController, Events } from "ionic-angular";

import { BluetoothSerial } from "@ionic-native/bluetooth-serial";

import { ObdServiceProvider, CommonFunctionProvider } from "../../providers";
import { TOPIC_CONSOLE_LOG, TOPIC_OUTPUT_DATA } from "../../util/Constants";

@Component({
  selector: "page-home",
  templateUrl: "home.html"
})
export class HomePage {
  segment: string = "action";
  connectedDevice: string;
  inputCommand: string = "";
  consoleLog: string = "Console Log";
  deviceList: any[];
  constructor(
    public navCtrl: NavController,
    public events: Events,
    private obdServiceProvider: ObdServiceProvider,
    private commonFunctionProvider: CommonFunctionProvider,
    private bluetoothSerial: BluetoothSerial,
    private zone: NgZone
  ) {
    this.events.subscribe(TOPIC_CONSOLE_LOG, log => {
      this.consoleLog += "<br/>" + log;
    });

    this.events.subscribe(TOPIC_OUTPUT_DATA, data => {
      this.log(
        "Output:" +
          CommonFunctionProvider.bufferArray2hexString(data[0]) +
          "(" +
          CommonFunctionProvider.arrayBufferToString(data[0]) +
          ")"
      );
    });
  }

  ionViewDidLoad() {
    this.bluetoothSerial.list().then(list => {
      this.deviceList = list;
      // this.log(JSON.stringify(list));
    });
    // this.bluetoothSerial
    //   .isConnected()
    //   .then(data => {
    //     this.connectedDevice = "Some Device > " + data;
    //     this.obdServiceProvider.init();
    //   })
    //   .catch(error => {
    //     this.connectedDevice = "None";
    //   });
  }

  selectDevice(device) {
    this.bluetoothSerial
      .isConnected()
      .then(() => {
        this.bluetoothSerial.disconnect().then(() => {
          this.log("Disconnected to current device");
          this.connectDevice(device);
        });
      })
      .catch(() => {
        this.connectDevice(device);
      });
  }

  connectDevice(device) {
    this.commonFunctionProvider.presentLoading(
      "Connecting to device:" + device.name
    );

    this.bluetoothSerial.connect(device.address).subscribe(
      data => {
        this.commonFunctionProvider.dismissLoading();
        this.connectedDevice = device.name;
        this.obdServiceProvider.init();
        this.log("Device connected:" + JSON.stringify(data));
        this.commonFunctionProvider.showAlert(
          "Device connected:" + device.name
        );
      },
      error => {
        this.commonFunctionProvider.dismissLoading();
        this.commonFunctionProvider.showAlert(
          "Unable to connect:" + device.name
        );
        this.log("Unable to connect:" + JSON.stringify(error));
      }
    );
  }

  sendCommand() {
    this.obdServiceProvider.sendCommand(this.inputCommand);
    this.inputCommand = "";
  }

  private log(message) {
    console.log(message);
    this.zone.run(() => {
      this.consoleLog += "<br/>" + message;
    });
  }
}
