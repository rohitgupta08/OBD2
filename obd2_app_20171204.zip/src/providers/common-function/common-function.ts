import { Injectable } from "@angular/core";
import {
  ToastController,
  LoadingController,
  Loading,
  AlertController,
  Alert
} from "ionic-angular";
import "rxjs/add/operator/map";

@Injectable()
export class CommonFunctionProvider {
  private progressDialog: Loading;
  private alertDialog: Alert;

  constructor(
    private toastCtrl: ToastController,
    private alertCtrl: AlertController,
    private loadingCtrl: LoadingController
  ) {}

  public static createCopyOfJSON(object): any {
    return JSON.parse(JSON.stringify(object));
  }

  public static bufferArray2hexString(buffer) {
    // buffer is an ArrayBuffer
    return Array.prototype.map
      .call(new Uint8Array(buffer), x => ("00" + x.toString(16)).slice(-2))
      .join("");
  }

  public static arrayBufferToString(buffer) {
    var arr = new Uint8Array(buffer);
    var str = String.fromCharCode.apply(String, arr);
    if (/[\u0080-\uffff]/.test(str)) {
      throw new Error(
        "this string seems to contain (still encoded) multibytes"
      );
    }
    return str;
  }

  public presentToast(message: string, duration: number = 2000) {
    let toast = this.toastCtrl.create({
      message: message,
      duration: duration
    });
    toast.present();
  }

  /**
   * This function is responsible to display alert box for validations.
   */
  showAlert(message: string) {
    this.dismissAlert();
    this.alertDialog = this.alertCtrl.create({
      title: "Laundary App",
      message: message,
      buttons: ["OK"]
    });

    this.alertDialog.onDidDismiss(() => {
      this.alertDialog = undefined;
    });

    this.alertDialog.present();
  }

  /**
   * Dismiss the alert dialog and return true if dialog is dismissed successfully
   */
  dismissAlert(): boolean {
    if (this.alertDialog) {
      this.alertDialog.dismiss();
      this.alertDialog = undefined;
      return true;
    }

    return false;
  }

  /**
   * Present loading screen.
   */
  presentLoading(message: string) {
    this.dismissLoading();
    this.progressDialog = this.loadingCtrl.create({
      content: message,
      cssClass: "custom_loading_dialog"
    });

    this.progressDialog.present();
  }

  /**
   * Dismiss loading screen.
   */
  dismissLoading() {
    if (this.progressDialog) {
      this.progressDialog.dismiss();
      this.progressDialog = undefined;
    }
  }
}
