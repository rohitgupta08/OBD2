import { Injectable } from "@angular/core";
import { Events } from "ionic-angular";

import { BluetoothSerial } from "@ionic-native/bluetooth-serial";

import { PIDUtils } from "../../util/PIDUtils";
import { TOPIC_CONSOLE_LOG, TOPIC_OUTPUT_DATA } from "../../util/Constants";

@Injectable()
export class ObdServiceProvider {
  private static INITIAL_COMMANDS: any[] = [
    {
      name: "Reset",
      command: "AT Z"
    },
    {
      name: "Set Protocol",
      command: "AT SP 0"
    },
    {
      name: "Echo off",
      command: "AT E0"
    },
    {
      name: "Disable Header",
      command: "AT H0"
    },
    {
      name: "Disable Line Feed",
      command: "AT L0"
    }
  ];

  constructor(
    public events: Events,
    private bluetoothSerial: BluetoothSerial
  ) {}

  init(): any {
    this.bluetoothSerial.subscribeRawData().subscribe(
      data => {
        this.events.publish(TOPIC_OUTPUT_DATA, [data]);
      },
      error => {
        this.log("Error in reading output:" + JSON.stringify(error));
      }
    );
    let initialCommandPromise = Promise.resolve();
    for (let item of ObdServiceProvider.INITIAL_COMMANDS) {
      initialCommandPromise = initialCommandPromise.then(() => {
        return this.sendCommand(item.command);
      });
    }
  }

  sendCommand(command) {
    this.log("Sending command:" + command);
    return this.bluetoothSerial
      .write(command + "\r")
      .then(res => {
        this.log(`Response:` + JSON.stringify(res));
      })
      .catch(err => {
        this.log(`Error response:` + JSON.stringify(err));
      });
  }

  // private reset() {
  //   let self = this;
  //   return this.bluetoothSerial
  //     .write("")
  //     .then(res => {
  //       self.log("Reset response:" + JSON.stringify(res));
  //     })
  //     .catch(err => {
  //       self.log("Reset response error:" + JSON.stringify(err));
  //     });
  // }

  /**
   * http://en.wikipedia.org/wiki/OBD-II_PIDs#Mode_1_PID_00
   * Each bit, from MSB to LSB, represents one of the next 32 PIDs and
   * is giving information about if it is supported.
   *
   * @param obdMode
   * @returns {*}
   */
  getSupportedPids() {
    let self = this;
    return this.bluetoothSerial.isConnected().then(
      () => {
        return this.bluetoothSerial.write("01 00").then(function(res) {
          self.log("Supported pids response 1:" + JSON.stringify(res));

          let pids = PIDUtils.decodeSupportedPids(res.data, 1);

          if ((res.data[3] & 0x01) == 0) return pids; // Check if supports pids [21 - 40]
          pids.pop(); // Remove PID 0x20
          return self.bluetoothSerial.write("01 20").then(function(res) {
            self.log("Supported pids response 2:" + JSON.stringify(res));

            pids = pids.concat(PIDUtils.decodeSupportedPids(res.data, 33));

            if ((res.data[3] & 0x01) == 0) return pids; // Check if supports pids [41 - 60]
            pids.pop(); // Remove PID 0x40
            return self.bluetoothSerial.write("01 40").then(function(res) {
              self.log("Supported pids response 3:" + JSON.stringify(res));

              pids = pids.concat(PIDUtils.decodeSupportedPids(res.data, 65));

              if ((res.data[3] & 0x01) == 0) return pids; // Check if supports pids [61 - 80]
              pids.pop(); // Remove PID 0x60
              return self.bluetoothSerial.write("01 60").then(function(res) {
                self.log("Supported pids response 4:" + JSON.stringify(res));

                pids = pids.concat(PIDUtils.decodeSupportedPids(res.data, 97));

                if ((res.data[3] & 0x01) == 0) return pids; // Check if supports pids [81 - A0]
                pids.pop(); // Remove PID 0x80
                return self.bluetoothSerial
                  .write([0x01, 0x80])
                  .then(function(res) {
                    return Promise.resolve(
                      pids.concat(PIDUtils.decodeSupportedPids(res.data, 129))
                    );
                  });
              });
            });
          });
        });
      },
      error => {
        this.log("Device not connected:" + JSON.stringify(error));
      }
    );
  }

  private log(message) {
    console.log(message);
    this.events.publish(TOPIC_CONSOLE_LOG, [message]);
  }
}
